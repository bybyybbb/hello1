@@ .. @@
 export default function Hero() {
   return (
     <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-green-900 via-green-800 to-emerald-900 px-4 sm:px-6 lg:px-8">
+      {/* Logo at top */}
+      <div className="absolute top-4 sm:top-6 left-4 sm:left-6 z-20">
+        <img 
   )
 }
+          src="/logo.jpg" 
+          alt="PEPUMP Logo" 
+          className="w-12 h-12 sm:w-16 sm:h-16 rounded-full border-2 border-green-400 shadow-lg hover:scale-110 transition-transform duration-300"
+        />
+      </div>
+      
       {/* Animated background elements */}
       <div className="absolute inset-0">
         <div className="absolute top-20 left-10 w-32 h-32 bg-green-400 rounded-full opacity-20 animate-pulse"></div>