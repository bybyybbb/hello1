@@ .. @@
   const connectWallet = async () => {
     if (!window.solana) {
       // Check if we're on mobile
       const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
       
       if (isMobile) {
         // Create proper deep link for iOS Phantom wallet connection
         const currentUrl = window.location.href;
         const encodedUrl = encodeURIComponent(currentUrl);
         const phantomDeepLink = `https://phantom.app/ul/browse/${encodedUrl}?ref=${encodedUrl}`;
         
         // For iOS, we need to use a different approach
         const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
         
         if (isIOS) {
           // Try to open Phantom app with proper connection intent
           const phantomConnectLink = `phantom://browse?url=${encodedUrl}`;
           
           // First try the app scheme
           window.location.href = phantomConnectLink;
           
           // Fallback to universal link after a short delay
           setTimeout(() => {
             window.location.href = phantomDeepLink;
           }, 500);
           
           setError('Opening Phantom app... Please approve the connection in Phantom.');
         } else {
           // Android handling
           window.location.href = phantomDeepLink;
           setError('Opening Phantom app... If it doesn\'t open, please install Phantom from your app store.');
         }
       } else {
         setError('Phantom wallet not found! Please install Phantom wallet.');
         window.open('https://phantom.app/', '_blank');
       }
       return;
     }

     try {
       setIsConnecting(true);
       setError('');
       
       const response = await window.solana.connect();
       const address = response.publicKey.toString();
       
       setIsConnected(true);
       setWalletAddress(address);
       
       // Show success message
       alert(`🐸 Welcome to the swamp, frog! 🐸\n\nWallet connected: ${address.slice(0, 4)}...${address.slice(-4)}`);
       
     } catch (err) {
       let errorMessage = 'Failed to connect wallet. Please try again.';
       
       if (err instanceof Error) {
         if (err.message.includes('User rejected')) {
           errorMessage = 'Connection cancelled. Please try again when ready to connect.';
         } else if (err.message.includes('timeout')) {
           errorMessage = 'Connection timeout. Please make sure Phantom is installed and try again.';
         } else {
           errorMessage = err.message;
         }
       }
       
       setError(errorMessage);
       console.error('Wallet connection error:', err);
     } finally {
       setIsConnecting(false);
     }
   };